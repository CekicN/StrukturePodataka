#include"LList.h"
int main()
{
	LList* list = new LList();
	list->addToHead(8);
	list->addToHead(6);
	list->addToHead(4);
	list->addToHead(4);
	list->addToHead(1);

	list->printAll();
	list->FillInBlanks();
	list->printAll();

	delete list;
	return 0;
}