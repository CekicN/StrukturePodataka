#pragma once
class HashTable
{
protected:
	int n;
	int br; 
	int k;
public:
	unsigned int g(int i, int j);
	unsigned int f(int i, int j);
	unsigned int h(int k);
};

